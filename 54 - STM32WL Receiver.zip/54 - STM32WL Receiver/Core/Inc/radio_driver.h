/*
 * radio_driver.h
 *
 *  Created on: May 2, 2025
 *      Author: Ceyhun
 */

#ifndef __RADIO_DRIVER_H
#define __RADIO_DRIVER_H

#include "radio.h"  // From SubGHz_Phy driver
#include "main.h"

// Radio function prototypes
void RadioInit(void);
void RadioOnTxDone(void);
void RadioOnRxDone(uint8_t *payload, uint16_t size, int16_t rssi, int8_t snr);

#endif /* __RADIO_DRIVER_H */
