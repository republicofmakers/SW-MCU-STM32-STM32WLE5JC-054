/*
 * radio_driver.c
 *
 *  Created on: May 2, 2025
 *      Author: Ceyhun
 */


#include "radio_driver.h"

// Define the global Radio event structure
RadioEvents_t RadioEvents;

void RadioInit(void) {
  // Set callbacks depending on application
  RadioEvents.TxDone = RadioOnTxDone;
  RadioEvents.RxDone = RadioOnRxDone;

  Radio.Init(&RadioEvents);
  Radio.SetChannel(868000000);  // Your frequency

  // Use appropriate config based on your role
#ifdef USE_TRANSMITTER
  Radio.SetTxConfig(MODEM_LORA, 14, 0, 0, 7, 1, 8, false, true, 0, 0, false, 3000);
#else
  Radio.SetRxConfig(
      MODEM_LORA,      // 1. Modem type
      0,               // 2. Bandwidth: 0 = 125 kHz
      7,               // 3. Spreading Factor (SF7)
      1,               // 4. Coding rate: 4/5
      0,               // 5. AFC bandwidth (not used for LORA)
      8,               // 6. Preamble length
      0,               // 7. Symbol timeout (0 = continuous)
      false,           // 8. Fixed length
      0,               // 9. Payload length (ignored if fixed length is false)
      true,            // 10. Enable CRC
      false,           // 11. Frequency hopping
      0,               // 12. Hop period
      false,           // 13. IQ inversion
      true             // 14. Continuous RX
  );
  Radio.Rx(0);  // Continuous RX
#endif
}

void RadioOnTxDone(void) {
#ifdef USE_TRANSMITTER
  Radio.Sleep();  // Optional
#endif
}

void RadioOnRxDone(uint8_t *payload, uint16_t size, int16_t rssi, int8_t snr)
{
    static uint8_t led_state = 0;

    // Toggle the state
    led_state ^= 1;

    // Apply the new state to LED pin (PA9)
    HAL_GPIO_WritePin(GPIOA, GPIO_PIN_9, led_state ? GPIO_PIN_SET : GPIO_PIN_RESET);

    // Re-enable receiving after handling the packet
    Radio.Rx(0);
}
